const express = require('express');
const { register, login, deleteUser, getDoctor } = require('../Controller/authController');
const router = express.Router();
const AuthMiddleware = require('../Middleware/AuthMiddleware');

router.post('/register', register);
router.post('/login', login);
// router.get('/users', getAllUsers);
router.get('/doctor', getDoctor);
// router.get('/patient', getAllUsers);
router.delete('/delete', AuthMiddleware, deleteUser);

module.exports = router;
