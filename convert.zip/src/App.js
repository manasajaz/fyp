import React from 'react'
import AppRouter from './config/router.jsx'
import "./App.css";


function App() {
  return (
    <div>
      <AppRouter />
    </div>
  );
}

export default App
